package com.ohgiraffers.section02.problem2;

public class Monster {
//    String name;
//    int hp;

    String kinds;
    int mp;

    public void setInfo1(String info1){
        this.kinds = info1;
    }

    public void setInfo2(int info2){
        this.mp = info2;
    }
}

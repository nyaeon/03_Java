package com.ohgiraffers.section01.user_type;

public class Member {
    String id;
    String pwd;
    String name;
    int age;
    char gender;
    String[] hobby;
}

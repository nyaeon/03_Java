package com.ohgiraffers.section03.math;

public class Application1 {

    public static void main(String[] args) {
        System.out.println("-12.4의 절대값 : " + Math.abs(-12.4));
        System.out.println("10과 20 중 더 작은 것은? : " + Math.min(10, 20));
        System.out.println("10과 20 중 더 큰 것은? : " + Math.max(10, 20));
        System.out.println("난수 생성 : " + Math.random());
    }
}

package com.ohgiraffers.section02.looping;

public class Application {
    public static void main(String[] args) {

//        A_for a = new A_for();
//        a.testSimpleForStatement();

        A_nestedFor b = new A_nestedFor();
//        b.printGugudanFromTowToNine();
//        b.printGugudanOf();
//        b.printStarInputRowTimes();
//        b.printTriangleStar();

        B_while c = new B_while();
//        c.testSimpleWhileStatement();
//        c.testWhileExample();

        D_dowhile d = new D_dowhile();
//        d.testSimpleDoWhileStatement();
        d.testDoWhile();


    }
}
